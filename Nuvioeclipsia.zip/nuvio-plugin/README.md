# Eclipsia

A Curated Collection of Providers for **[Nuvio](https://github.com/NuvioMedia)**
<br>Visit site to install plugins or see details: **[Eclipsia](https://eclipsia.codeberg.page)**
# **Installation**

Go to **[Eclipsia Setup Wizard](https://eclipsia.codeberg.page/guide)** & Follow the steps.

> [!IMPORTANT]
> You MUST set TMDB API Key in **Settings → Integrations → TMDB Enrichment**\
> Otherwise plugins will not work reliably.

# **DMCA Notice**
<p align="justify">We issue this notice to clarify that these plugins operate like standard web browsers by retrieving video files from the Internet and do not, by themselves, contravene the Digital Millennium Copyright Act (17 U.S.C. §§ 1201–1205, 17 U.S.C. § 512) or other applicable law. Any content accessed through the plugins is provided by third-party websites or file hosts and is not hosted, controlled, or maintained by this repository or the Nuvio application, and users are solely responsible for ensuring their use complies with applicable copyright, licensing, contract, and other laws. Pursuant to the DMCA, copyright owners seeking removal of infringing material should follow the notice-and-takedown procedures set forth in 17 U.S.C. §§ 1201–1205, 17 U.S.C. § 512. If you believe any content accessed via the plugins infringes intellectual property rights, please direct your complaints to the hosting websites or file hosts rather than to the repository maintainers or the Nuvio application developers.</p>

# **Disclaimer**
<p align="justify">
This project is provided for educational and informational purposes only; users are solely responsible for ensuring their use complies with all applicable laws, regulations, and professional standards. The authors, contributors, and distributors make no warranties—express or implied—and disclaim liability for any direct, indirect, incidental, consequential, or other damages arising from use of the project. Before relying on the project for operational, legal, or commercial purposes, obtain independent professional advice and verify compliance with local requirements.</p>

# **License**

This project is licensed under the GNU Affero General Public License v3.0 or later - see the LICENSE file for details.
